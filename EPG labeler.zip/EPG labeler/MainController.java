package application;


import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.FileChooser;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;

import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Label;


import java.io.*;
import java.util.ArrayList;
import java.util.List;



public class MainController {

    @FXML
    private ListView<String> listView;

    @FXML
    private LineChart<Number, Number> lineChart;

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private NumberAxis xAxis;

    @FXML
    private NumberAxis yAxis;

    @FXML
    private Button Upload;

    @FXML
    private Button Draw;

    @FXML
    private Button Export;
    
    @FXML
    private Label coordinateLabel;
    
    @FXML
    private TextField labelTextField;
    
    @FXML
    private Button labelButton;

    private int selectedDataIndex = -1;
    
    @FXML
    private Label selectedIndexLabel;
    
    @FXML
    private VBox colorBarContainer;
    
    @FXML
    private TextField minKernelTextField;

    @FXML
    private TextField maxKernelTextField;

    @FXML
    private Button peakDetectionButton;
    
    @FXML
    private Button troughDetectionButton;


    private String[] classNames = {
        "Class 0", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", "Class 6", "Class 7", "Class 8", "Class 9"
    };


    private List<Double> epgValues = new ArrayList<>();
    private List<Integer> labelClasses = new ArrayList<>();

    public void initialize() {
        // 初始化LineChart和ListView

        yAxis.setAutoRanging(false);
        yAxis.setLowerBound(-3.5);
        yAxis.setUpperBound(-0.5);

        Upload.setOnAction(event -> uploadCSV());
        Draw.setOnAction(event -> drawEPGAndLabels());
        Export.setOnAction(event -> exportCSV());
        labelButton.setOnAction(event -> applyLabelToDataPoint());
        peakDetectionButton.setOnAction(event -> performPeakDetection());
        troughDetectionButton.setOnAction(event -> performTroughDetection());

        
        for (int i = 0; i < classNames.length; i++) {
            Rectangle colorRectangle = new Rectangle(20, 20, Color.web(getColorForLabelClass(i)));
            Label classLabel = new Label(classNames[i]);
            VBox colorBox = new VBox(colorRectangle, classLabel);
            colorBarContainer.getChildren().add(colorBox);
            
        }

        
     // Set up the mouseMoved event handler for the LineChart
        lineChart.setOnMouseMoved(this::handleLineChartMouseMoved);
        

     // Set up the mouseClicked event handler for the LineChart
        lineChart.setOnMouseClicked(this::handleLineChartMouseClicked);
        
        
        
        
        
     // Attach an event listener to the labelTextField
        //labelTextField.setOnKeyPressed(event -> {
            //if (event.getCode() == KeyCode.ENTER) {
                //applyLabelToDataPoint();
            //}
        //});
    }
        
 

    

    private void uploadCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showOpenDialog(Upload.getScene().getWindow());
        if (file != null) {
            listView.getItems().add(file.getAbsolutePath());
            readCSV(file);
        }
    }
    
    private List<Integer> labeledLabelClasses;
    
    private void readCSV(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length == 2) {
                    double epgValue = Double.parseDouble(values[0]);
                    int labelClass = Integer.parseInt(values[1]);
                    epgValues.add(epgValue);
                    labelClasses.add(labelClass);
                }
            }

            // Create a deep copy of labelClasses and set it to labeledLabelClasses
            labeledLabelClasses = new ArrayList<>(labelClasses);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private String getColorForLabelClass(int labelClass) {
        String[] colors = {
                "#FF0000", "#0000FF", "#00FF00", "#FFFF00", "#FF00FF", "#00FFFF", "#FFA500", "#800080", "#008000", "#000080"
        };
        if (labelClass >= 0 && labelClass < colors.length) {
            return colors[labelClass];
        }
        return "#000000"; // Default color if label class is out of range
    }
    

    private void drawEPGAndLabels() {
        lineChart.getData().clear();
        XYChart.Series<Number, Number> series = new XYChart.Series<>();

        int index = 0; // Start the index from 0

        for (int i = 0; i < epgValues.size(); i++) {
            double epgValue = epgValues.get(i);

            XYChart.Data<Number, Number> dataPoint = new XYChart.Data<>(index, epgValue);
            series.getData().add(dataPoint);
            index++;
        }

        lineChart.getData().add(series);

        // Calculate and set the LineChart's width based on the number of data points
        double dataPointSize = epgValues.size();
        double dataPointWidth = 2; // You can adjust this as needed
        double totalWidth = dataPointSize * dataPointWidth;
        lineChart.setPrefWidth(totalWidth);

        // Set the colors of the data points after the line chart is drawn
        Platform.runLater(() -> {
            for (int i = 0; i < epgValues.size(); i++) {
                XYChart.Data<Number, Number> dataPoint = series.getData().get(i);
                int labelClass = labelClasses.get(i);
                String color = getColorForLabelClass(labelClass);
                //System.out.println("Data Point " + i + " Color: " + color);
                dataPoint.getNode().setStyle("-fx-background-color: " + color + ";");
            }
        });
    }



    private void handleLineChartMouseMoved(MouseEvent event) {
        // Get the mouse cursor's X coordinate on the LineChart's X-axis
        double xCoordinate = xAxis.sceneToLocal(event.getSceneX(), 0).getX();

        // Find the nearest data point to the cursor's X coordinate
        double nearestXCoordinate = Double.NaN;
        double nearestYCoordinate = Double.NaN;
        double minDistance = Double.MAX_VALUE;

        for (XYChart.Data<Number, Number> data : lineChart.getData().get(0).getData()) {
            double dataX = xAxis.getDisplayPosition(data.getXValue());
            double dataY = yAxis.getDisplayPosition(data.getYValue());
            double distance = Math.abs(dataX - xCoordinate);

            if (distance < minDistance) {
                minDistance = distance;
                nearestXCoordinate = data.getXValue().doubleValue();
                nearestYCoordinate = data.getYValue().doubleValue();
            }
        }
        
     // Compute the convolution using the kernel [-1, -1, 4, -1, -1] and get the nearest kernel value
        double[] kernel = {-1, -1, -1, 6, -1, -1, -1};
        int kernelSize = kernel.length;
        int nearestIndex = (int) nearestXCoordinate;
        double kernelValue = 0;

        for (int i = 0; i < kernelSize; i++) {
            int dataIndex = nearestIndex - kernelSize / 2 + i;
            if (dataIndex >= 0 && dataIndex < epgValues.size()) {
                kernelValue += kernel[i] * epgValues.get(dataIndex);
            }
        }

        // Update the coordinateLabel to display the nearest data point's coordinates and kernel value
        coordinateLabel.setText(String.format("X: %.2f, Y: %.2f, Kernel: %.2f", nearestXCoordinate, nearestYCoordinate, kernelValue));
    }
    
    private void handleLineChartMouseClicked(MouseEvent event) {
        if (event.getButton() == MouseButton.PRIMARY) {
            // Get the mouse cursor's X coordinate on the LineChart's X-axis
            double xCoordinate = xAxis.sceneToLocal(event.getSceneX(), 0).getX();

            // Find the nearest data point to the cursor's X coordinate
            double nearestXCoordinate = Double.NaN;
            double nearestYCoordinate = Double.NaN;
            double minDistance = Double.MAX_VALUE;

            for (XYChart.Data<Number, Number> data : lineChart.getData().get(0).getData()) {
                double dataX = xAxis.getDisplayPosition(data.getXValue());
                double dataY = yAxis.getDisplayPosition(data.getYValue());
                double distance = Math.abs(dataX - xCoordinate);

                if (distance < minDistance) {
                    minDistance = distance;
                    nearestXCoordinate = data.getXValue().doubleValue();
                    nearestYCoordinate = data.getYValue().doubleValue();
                }
            }

            // Update the coordinateLabel to display the coordinates of the selected data point
            selectedIndexLabel.setText(String.format("Selected Point: X=%.2f, Y=%.2f", nearestXCoordinate, nearestYCoordinate));

            // Save the selected data index for applying the label later
            selectedDataIndex = (int) nearestXCoordinate;
        }
    }
    

    private void applyLabelToDataPoint() {
        String labelText = labelTextField.getText();
        if (!labelText.isEmpty() && selectedDataIndex >= 0 && selectedDataIndex < labeledLabelClasses.size()) {
            int labelValue = Integer.parseInt(labelText);
            labeledLabelClasses.set(selectedDataIndex, labelValue); // Update the labeledLabelClasses list instead of labelClasses

            // Get the data point for the selected index
            XYChart.Series<Number, Number> series = lineChart.getData().get(0);
            if (selectedDataIndex >= 0 && selectedDataIndex < series.getData().size()) {
                XYChart.Data<Number, Number> dataPoint = series.getData().get(selectedDataIndex);

                // Get the label class for the data point
                int labelClass = labeledLabelClasses.get(selectedDataIndex);

                // Set the color of the data point based on the labelClass
                String color = getColorForLabelClass(labelClass);
                dataPoint.getNode().setStyle("-fx-background-color: " + color + ";");
                
             // Set the data point's radius to 3 pixels
             //  dataPoint.getNode().setStyle("-fx-background-radius: 3px;");
            }
        }
    }
 
    private double calculateKernelValue(int dataIndex) {
        double[] kernel = {-1, -1, -1, 6, -1, -1, -1};
        int kernelSize = kernel.length;
        int nearestIndex = dataIndex;
        double kernelValue = 0;

        for (int i = 0; i < kernelSize; i++) {
            int index = nearestIndex - kernelSize / 2 + i;
            if (index >= 0 && index < epgValues.size()) {
                kernelValue += kernel[i] * epgValues.get(index);
            }
        }

        return kernelValue;
    }
    
    private void performPeakDetection() {
        String minKernelText = minKernelTextField.getText();
        String maxKernelText = maxKernelTextField.getText();
        String labelText = labelTextField.getText(); // Get the class label from the text field

        if (!minKernelText.isEmpty() && !maxKernelText.isEmpty() && !labelText.isEmpty()) {
            double minKernelValue = Double.parseDouble(minKernelText);
            double maxKernelValue = Double.parseDouble(maxKernelText);

            // Convert the label text to an integer for class assignment
            int selectedClass = Integer.parseInt(labelText);

            // Iterate over the epgValues and apply labels based on kernel values and neighboring values
            for (int i = 1; i < epgValues.size() - 1; i++) {
                double kernelValue = calculateKernelValue(i);
                double prevEpgValue = epgValues.get(i - 1);
                double nextEpgValue = epgValues.get(i + 1);

                if (kernelValue >= minKernelValue && kernelValue <= maxKernelValue &&
                        epgValues.get(i) > prevEpgValue && epgValues.get(i) > nextEpgValue) {
                    labeledLabelClasses.set(i, selectedClass); // Update the label class
                    int labelClass = labeledLabelClasses.get(i);
                    String color = getColorForLabelClass(labelClass);
                    XYChart.Data<Number, Number> dataPoint = lineChart.getData().get(0).getData().get(i);
                    dataPoint.getNode().setStyle("-fx-background-color: " + color + ";");
                }
            }
        }
    }
    
    private void performTroughDetection() {
    	String minKernelText = minKernelTextField.getText();
        String maxKernelText = maxKernelTextField.getText();
        String labelText = labelTextField.getText(); // Get the class label from the text field

        if (!minKernelText.isEmpty() && !maxKernelText.isEmpty() && !labelText.isEmpty()) {
            double minKernelValue = Double.parseDouble(minKernelText);
            double maxKernelValue = Double.parseDouble(maxKernelText);
            

            // Convert the label text to an integer for class assignment
            int selectedClass = Integer.parseInt(labelText);

            // Iterate over the epgValues and apply labels based on trough conditions and neighboring values
            for (int i = 1; i < epgValues.size() - 1; i++) {
                double kernelValue = calculateKernelValue(i);
                double prevEpgValue = epgValues.get(i - 1);
                double nextEpgValue = epgValues.get(i + 1);

                if (kernelValue >= minKernelValue && kernelValue <= maxKernelValue &&
                        epgValues.get(i) < prevEpgValue && epgValues.get(i) < nextEpgValue) {
                    labeledLabelClasses.set(i, selectedClass); // Update the label class
                    int labelClass = labeledLabelClasses.get(i);
                    String color = getColorForLabelClass(labelClass);
                    XYChart.Data<Number, Number> dataPoint = lineChart.getData().get(0).getData().get(i);
                    dataPoint.getNode().setStyle("-fx-background-color: " + color + ";");
           
                }
            }
        }
    }



    
    private void exportCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showSaveDialog(Export.getScene().getWindow());
        if (file != null) {
            try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
                for (int i = 0; i < epgValues.size(); i++) {
                    double epgValue = epgValues.get(i);
                    int labelClass = labeledLabelClasses.get(i); // Export the labeled data from labeledLabelClasses
                    writer.println(epgValue + "," + labelClass);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


 

}